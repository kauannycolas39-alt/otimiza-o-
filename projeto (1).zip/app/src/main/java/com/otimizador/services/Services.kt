package com.otimizador

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.random.Random

fun Context.activity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

object Util {
    fun copy(ctx: Context, text: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("nitro", text))
    }

    fun openUrl(ctx: Context, url: String) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) { }
    }

    fun xit(ctx: Context) {
        Toast.makeText(ctx, t("no_hack"), Toast.LENGTH_LONG).show()
        Handler(Looper.getMainLooper()).postDelayed({ ctx.activity()?.finishAffinity() }, 1500)
    }

    fun loadBg(ctx: Context, s: String): ImageBitmap? = try {
        val uri = Uri.parse(s)
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = 1
        while (o.outWidth / ss > 1400) ss *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = ss
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }?.asImageBitmap()
    } catch (e: Throwable) { null }
}

/** Execução de comandos de shell via Shizuku (sem root). */
object Shell {
    fun status(): String {
        try {
            if (!Shizuku.pingBinder()) return "off"
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return "perm"
            return "ok"
        } catch (e: Throwable) {
            return "off"
        }
    }

    fun available(): Boolean = status() == "ok"

    fun requestPermission() {
        try { Shizuku.requestPermission(100) } catch (e: Throwable) { }
    }

    fun run(script: String): Pair<Boolean, String> {
        try {
            val wrapped = "(" + script + ") 2>&1"
            val cmd = arrayOf("sh", "-c", wrapped)
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, cmd, null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            return Pair(code == 0, out.trim())
        } catch (e: Throwable) {
            return Pair(false, e.message ?: "erro")
        }
    }
}

/** Leitura real de dados do aparelho. Dado indisponível = null. */
object Device {
    fun status(ctx: Context): DeviceStatus {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val sf = StatFs(Environment.getDataDirectory().path)
        val total = sf.blockCountLong * sf.blockSizeLong
        val free = sf.availableBlocksLong * sf.blockSizeLong
        val gb = 1024.0 * 1024.0 * 1024.0
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val t = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val v = b?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        return DeviceStatus(
            (mi.totalMem - mi.availMem) / 1048576L, mi.totalMem / 1048576L,
            (total - free) / gb, total / gb,
            if (t == Int.MIN_VALUE || t <= 0) null else t / 10f,
            if (lvl >= 0 && sc > 0) lvl * 100 / sc else null,
            if (st < 0) null else (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL),
            if (v <= 0) null else v / 1000f
        )
    }

    fun refreshRate(ctx: Context): Int {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        return d?.refreshRate?.roundToInt() ?: 60
    }

    fun detect(ctx: Context): DeviceProfile {
        val dm = ctx.resources.displayMetrics
        val wi = dm.widthPixels / dm.xdpi.toDouble()
        val hi = dm.heightPixels / dm.ydpi.toDouble()
        val diag = (sqrt(wi * wi + hi * hi) * 10).roundToInt() / 10.0
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ram = mi.totalMem / 1024.0 / 1024.0 / 1024.0
        val tier = if (ram < 3.5) 1 else if (ram < 7.0) 2 else 3
        return DeviceProfile(Build.MANUFACTURER.uppercase(), Build.MODEL, ram, refreshRate(ctx), tier, diag)
    }

    fun details(ctx: Context): DeviceDetails {
        val dm = ctx.resources.displayMetrics
        val up = SystemClock.elapsedRealtime() / 60000L
        val abi = if (Build.SUPPORTED_ABIS.isNotEmpty()) Build.SUPPORTED_ABIS[0] else "?"
        return DeviceDetails(
            Build.MANUFACTURER.uppercase(), Build.MODEL,
            Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")", abi,
            Runtime.getRuntime().availableProcessors(), refreshRate(ctx),
            dm.widthPixels.toString() + "x" + dm.heightPixels, dm.densityDpi,
            (up / 60).toString() + "h " + (up % 60).toString() + "min"
        )
    }
}

object Net {
    fun online(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val c = if (n != null) cm.getNetworkCapabilities(n) else null
        c != null && c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Exception) { false }
}

/** Abertura dos jogos pelos mecanismos oficiais do Android. */
object Games {
    fun installed(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }

    fun preferred(ctx: Context): String? {
        val fav = Prefs.favFF
        if (fav.isNotBlank() && installed(ctx, fav)) return fav
        if (installed(ctx, Acts.FF_MAX)) return Acts.FF_MAX
        if (installed(ctx, Acts.FF)) return Acts.FF
        return null
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }

    fun openStore(ctx: Context, pkg: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Util.openUrl(ctx, "https://play.google.com/store/apps/details?id=" + pkg)
        }
    }

    fun openSettings(ctx: Context, action: String) {
        try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }
}

/** Lista de otimizações disponíveis (todas via shell do Shizuku, exceto as que abrem configurações). */
object Acts {
    const val FF = "com.dts.freefireth"
    const val FF_MAX = "com.dts.freefiremax"

    private fun anim(v: String): String =
        "settings put global window_animation_scale " + v + "\n" +
        "settings put global transition_animation_scale " + v + "\n" +
        "settings put global animator_duration_scale " + v

    private const val REFRESH = "settings put system peak_refresh_rate 120.0\nsettings put system min_refresh_rate 90.0"

    private fun game(pkg: String, mode: String): String =
        "settings put global low_power 0\n" + REFRESH + "\n" +
        "cmd game mode performance " + pkg + "\n" +
        "cmd power set-fixed-performance-mode-enabled true\n" +
        "cmd package compile -m " + mode + " " + pkg + "\n" +
        "am kill-all"

    private val fluidBase = anim("0.5") + "\n" + REFRESH + "\nsettings put secure long_press_timeout 300"

    val all = listOf(
        Act("fluid", fluidBase + "\ncmd package compile -m speed-profile -a"),
        Act("fluid_fast", fluidBase),
        Act("gm_max", game(FF_MAX, "speed -f")),
        Act("gm_ff", game(FF, "speed -f")),
        Act("gmf_max", game(FF_MAX, "speed-profile")),
        Act("gmf_ff", game(FF, "speed-profile")),
        Act("perf", "settings put global low_power 0\ncmd power set-fixed-performance-mode-enabled true"),
        Act("cache", "pm trim-caches 999999999999"),
        Act("kill", "am kill-all"),
        Act("anim_fast", anim("0.5")),
        Act("anim_off", anim("0")),
        Act("mouse_fast", "settings put system pointer_speed 7"),
        Act("mouse_def", "settings put system pointer_speed 0"),
        Act("restore", anim("1.0") + "\nsettings delete system peak_refresh_rate\nsettings delete system min_refresh_rate\n" +
            "settings put secure long_press_timeout 500\nsettings put system pointer_speed 0\ncmd power set-fixed-performance-mode-enabled false"),
        Act("battery", null, Settings.ACTION_BATTERY_SAVER_SETTINGS)
    )

    /** Ações exibidas na lista (as "_fast" são só para o modo automático). */
    val visible = listOf("fluid", "gm_max", "gm_ff", "perf", "cache", "kill", "anim_fast", "anim_off", "mouse_fast", "mouse_def", "restore", "battery")

    fun byId(id: String): Act? = all.firstOrNull { it.id == id }

    fun brevent(): String = fluidBase + "\n\n" + game(FF_MAX, "speed -f")
}

object Optimizer {
    fun run(ctx: Context, id: String): ActionResult {
        val act = Acts.byId(id) ?: return ActionResult(id, false, "?")
        val title = t("a_" + id.replace("gmf_", "gm_").replace("fluid_fast", "fluid"))
        if (act.script == null) return ActionResult(title, false, t("open_settings_note"), act.settings)
        if (id.startsWith("gm")) {
            val pkg = if (id.endsWith("max")) Acts.FF_MAX else Acts.FF
            if (!Games.installed(ctx, pkg)) return ActionResult(title, false, t("ff_not_installed"))
        }
        if (!Shell.available()) return ActionResult(title, false, t("need_shizuku"), Settings.ACTION_SETTINGS)
        val before = Device.status(ctx).ramUsedMb
        val r = Shell.run(act.script)
        val after = Device.status(ctx).ramUsedMb
        var msg = if (r.first) t("done_shizuku") else t("failed")
        if (id == "kill") msg += " RAM: " + before + " → " + after + " MB"
        if (r.second.isNotBlank()) msg += "\n" + r.second.take(300)
        return ActionResult(title, r.first, msg)
    }

    fun cleanOwnCache(ctx: Context): ActionResult {
        var freed = 0L
        fun del(f: File) {
            if (f.isDirectory) {
                f.listFiles()?.forEach { del(it) }
            } else {
                freed += f.length()
            }
            f.delete()
        }
        ctx.cacheDir.listFiles()?.forEach { del(it) }
        return ActionResult(t("a_own_cache"), true, t("own_cache_done") + " " + (freed / 1024) + " KB", Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
    }
}

object Notifier {
    private const val CH = "nitro_opt"

    fun optimized(ctx: Context) {
        if (!Prefs.notif) return
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(NotificationChannel(CH, "NitroCore", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val n = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(t("notif_title"))
                .setContentText(t("notif_text"))
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify(1, n)
        } catch (e: Throwable) { }
    }

    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun ask(ctx: Context) {
        if (!hasPermission(ctx)) {
            try { ctx.activity()?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77) } catch (e: Throwable) { }
        }
    }
}

/** Otimização automática: executa tudo e (opcionalmente) abre o Free Fire preferido. */
object Auto {
    fun ids(ctx: Context): List<String> {
        val l = mutableListOf("fluid_fast", "perf")
        if (Games.installed(ctx, Acts.FF_MAX)) l.add("gmf_max")
        if (Games.installed(ctx, Acts.FF)) l.add("gmf_ff")
        l.add("cache")
        l.add("kill")
        return l
    }

    fun run(ctx: Context, launch: Boolean, done: (List<ActionResult>) -> Unit) {
        thread {
            val res = ids(ctx).map { Optimizer.run(ctx, it) }
            if (res.any { it.ok }) Notifier.optimized(ctx)
            Handler(Looper.getMainLooper()).post {
                done(res)
                if (launch) {
                    val pkg = Games.preferred(ctx)
                    if (pkg != null) Games.launch(ctx, pkg)
                }
            }
        }
    }
}

object SensiEngine {
    fun suggest(game: Game, d: DeviceProfile, style: Int, fingers: Int, platform: Int, fbAdj: Int, jitter: Int, rnd: Random?): List<Int> {
        var adj = 0
        adj += when (d.tier) { 1 -> -4; 3 -> 3; else -> 0 }
        adj += if (d.hz >= 120) 3 else if (d.hz <= 60) -3 else 0
        adj += if (d.diag >= 6.7) 3 else if (d.diag >= 1.0 && d.diag < 6.3) -2 else 0
        adj += when (platform) { 1 -> 4; 2 -> 6; else -> 0 }
        adj += when (fingers) { 0 -> 5; 1 -> 2; else -> 0 }
        adj += fbAdj
        val st = STYLES[style.coerceIn(0, STYLES.size - 1)]
        return game.sliders.map { s ->
            val g = when (s.group) { 1 -> st.scope; 2 -> st.awm; else -> st.gen }
            val j = if (rnd != null && jitter > 0) rnd.nextInt(-jitter, jitter + 1) else 0
            val pct = (s.basePct + adj + g + j).coerceIn(2, 100)
            (s.min + (s.max - s.min) * pct / 100.0).roundToInt().coerceIn(s.min, s.max)
        }
    }
}

class AiException(msg: String) : Exception(msg)

interface AiProvider {
    fun sensi(payload: JSONObject): JSONObject
    fun searchSensi(payload: JSONObject): JSONObject
}

object Http {
    fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val st = if (code in 200..299) c.inputStream else c.errorStream
            val text = st?.bufferedReader()?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            c.disconnect()
        }
    }

    fun check(code: Int, text: String) {
        if (code in 200..299) return
        if (code == 401 || code == 403) throw AiException(t("ai_bad_key"))
        if (code == 404) throw AiException(t("ai_bad_model"))
        if (code == 429) throw AiException(t("ai_limit"))
        throw AiException("HTTP " + code + ": " + text.take(140))
    }
}

class BackendProvider(private val baseUrl: String) : AiProvider {
    private fun call(path: String, body: JSONObject): JSONObject {
        val r = Http.post(baseUrl.trimEnd('/') + path, emptyMap(), body.toString())
        Http.check(r.first, r.second)
        return JSONObject(r.second)
    }

    override fun sensi(payload: JSONObject): JSONObject = call("/api/sensi", payload)
    override fun searchSensi(payload: JSONObject): JSONObject = call("/api/search-sensi", payload)
}

/** Chamada direta ao provedor com a chave do próprio usuário (kind 1 = OpenAI/ChatGPT API, 2 = Claude API). */
class DirectProvider(private val kind: Int, private val key: String, private val model: String) : AiProvider {
    private fun ask(system: String, user: String): String {
        if (kind == 1) {
            val msgs = JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user))
            val body = JSONObject().put("model", model).put("temperature", 0.7).put("messages", msgs)
            val r = Http.post("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to ("Bearer " + key)), body.toString())
            Http.check(r.first, r.second)
            return JSONObject(r.second).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
        val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject().put("model", model).put("max_tokens", 900).put("system", system).put("messages", msgs)
        val r = Http.post("https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString())
        Http.check(r.first, r.second)
        val arr = JSONObject(r.second).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
        return sb.toString()
    }

    fun ping(): String = ask("Reply with the single word OK.", "ping")

    override fun sensi(payload: JSONObject): JSONObject {
        val system = "You help mobile shooter players tune in-game sensitivity. Reply ONLY with JSON: " +
            "{\"values\":{\"<control id>\":<integer>},\"explanation\":\"<max 3 short sentences>\"}. " +
            "Use exactly the control ids and respect min/max from \"scales\". Values are test suggestions: never promise aim assist, " +
            "headshots or guaranteed performance. Write the explanation in this language code: " + payload.optString("lang", "pt")
        val text = ask(system, payload.toString())
        val a = text.indexOf('{')
        val b = text.lastIndexOf('}')
        if (a < 0 || b <= a) throw AiException(t("ai_bad_reply"))
        val j = JSONObject(text.substring(a, b + 1))
        val sc = payload.optJSONObject("scales") ?: JSONObject()
        val src = j.optJSONObject("values") ?: JSONObject()
        val out = JSONObject()
        val keys = sc.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val lim = sc.getJSONObject(k)
            val v = src.optInt(k, Int.MIN_VALUE)
            if (v != Int.MIN_VALUE) out.put(k, v.coerceIn(lim.getInt("min"), lim.getInt("max")))
        }
        return JSONObject().put("values", out).put("explanation", j.optString("explanation")).put("sources", JSONArray()).put("verified", false)
    }

    override fun searchSensi(payload: JSONObject): JSONObject = throw AiException(t("ai_search_backend"))
}

object AiFactory {
    fun fixUrl(raw: String): String {
        var u = raw.trim().replace("https//:", "https://").replace("http//:", "http://")
        if (u.isNotEmpty() && !u.startsWith("http")) u = "https://" + u
        return u
    }

    fun defaultModel(kind: Int): String = if (kind == 2) "claude-sonnet-5-5" else "gpt-4o-mini"

    fun make(): Pair<AiProvider?, String?> {
        val kind = Prefs.aiKind
        if (kind == 1 || kind == 2) {
            if (Prefs.aiKey.isBlank()) return Pair(null, t("ai_no_key"))
            val model = if (Prefs.aiModel.isBlank()) defaultModel(kind) else Prefs.aiModel.trim()
            return Pair(DirectProvider(kind, Prefs.aiKey.trim(), model), null)
        }
        val u = fixUrl(Prefs.backendUrl)
        if (u.isBlank()) return Pair(null, t("ai_not_cfg"))
        val host = try { URL(u).host } catch (e: Exception) { "" }
        if (host.isBlank() || !host.contains(".")) return Pair(null, t("ai_bad_url"))
        if (host.contains("chatgpt.com") || host.contains("openai.com") || host.contains("claude.ai")) return Pair(null, t("ai_site_not_api"))
        return Pair(BackendProvider(u), null)
    }

    fun friendly(e: Throwable): String = when (e) {
        is AiException -> e.message ?: t("ai_error")
        is java.net.UnknownHostException -> t("ai_no_net")
        is java.net.SocketTimeoutException -> t("ai_timeout")
        else -> t("ai_error") + " (" + (e.message ?: e.javaClass.simpleName) + ")"
    }
}
