package com.otimizador

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import kotlin.random.Random

@Composable
fun SensiScreen() {
    val ctx = LocalContext.current
    val det = remember { Device.detect(ctx) }
    val rnd = remember { Random(System.nanoTime()) }
    var game by remember { mutableStateOf(Game.FF) }
    var brand by remember { mutableStateOf(det.brand) }
    var model by remember { mutableStateOf(det.model) }
    var ram by remember { mutableStateOf(String.format(Locale.US, "%.1f", det.ramGb)) }
    var hz by remember { mutableStateOf(det.hz.toString()) }
    var tier by remember { mutableStateOf(det.tier) }
    var diag by remember { mutableStateOf(det.diag) }
    var platform by remember { mutableStateOf(0) }
    var fingers by remember { mutableStateOf(2) }
    var style by remember { mutableStateOf(1) }
    var fb by remember { mutableStateOf(0) }
    var fbLabel by remember { mutableStateOf("") }
    var values by remember { mutableStateOf(Game.FF.sliders.map { it.def }) }
    var variants by remember { mutableStateOf<List<List<Int>>>(emptyList()) }
    var jitter by remember { mutableStateOf(8f) }
    var info by remember { mutableStateOf<String?>(null) }
    var showHow by remember { mutableStateOf(false) }
    var showLoad by remember { mutableStateOf(false) }
    var showPhones by remember { mutableStateOf(false) }
    var pickBrand by remember { mutableStateOf<String?>(null) }
    var gameVersion by remember { mutableStateOf("") }
    var difficulty by remember { mutableStateOf("") }
    var aiBusy by remember { mutableStateOf(false) }
    var aiMsg by remember { mutableStateOf<String?>(null) }
    var aiResult by remember { mutableStateOf<AiResult?>(null) }
    var consentDialog by remember { mutableStateOf(false) }
    var pendingSearch by remember { mutableStateOf(false) }

    val platforms = listOf(t("pl_phone"), t("pl_tablet"), t("pl_emu"))
    val fingerNames = listOf("2", "3", "4", "5+")

    fun dev() = DeviceProfile(brand, model, ram.replace(',', '.').toDoubleOrNull() ?: det.ramGb, hz.toIntOrNull() ?: det.hz, tier, diag)

    fun gen(j: Int, r: Random?): List<Int> = SensiEngine.suggest(game, dev(), style, fingers, platform, fb, j, r)

    fun pick(g: Game) { game = g; values = g.sliders.map { it.def }; fb = 0; fbLabel = ""; info = null; variants = emptyList() }

    fun asText(vals: List<Int>): String = game.display() + "\n" + game.sliders.mapIndexed { i, s -> t("s_" + s.id) + ": " + vals[i] }.joinToString("\n")

    fun save(vals: List<Int>) {
        Prefs.saveProfiles(Prefs.profiles() + Profile(game.display() + " · " + t("st_" + STYLES[style].id), game.name, vals, Prefs.now()))
        info = t("saved_profile")
    }

    fun callAi(search: Boolean) {
        val made = AiFactory.make()
        val prov = made.first
        if (prov == null) { aiMsg = made.second; return }
        if (!Prefs.aiConsent) { pendingSearch = search; consentDialog = true; return }
        if (!Net.online(ctx)) {
            aiResult = Prefs.lastAi()
            aiMsg = if (aiResult != null) t("offline_last") else t("offline_none")
            return
        }
        aiBusy = true
        aiMsg = null
        val d = dev()
        val cur = JSONObject()
        val scales = JSONObject()
        game.sliders.forEachIndexed { i, s ->
            cur.put(s.id, values[i])
            scales.put(s.id, JSONObject().put("min", s.min).put("max", s.max))
        }
        val payload = JSONObject()
            .put("lang", Prefs.lang).put("game", game.label.ifBlank { "Other" }).put("gameVersion", gameVersion.take(30))
            .put("brand", d.brand).put("model", d.model).put("ramGb", d.ramGb)
            .put("refreshHz", d.hz).put("category", d.tier).put("platform", platform).put("fingers", fingerNames[fingers])
            .put("style", STYLES[style].id).put("difficulty", difficulty.take(300))
            .put("feedback", fbLabel).put("currentValues", cur).put("scales", scales)
        thread {
            try {
                val j = if (search) prov.searchSensi(payload) else prov.sensi(payload)
                Prefs.saveLastAi(j.toString())
                aiResult = AiResult.parse(j)
            } catch (e: Throwable) {
                aiMsg = AiFactory.friendly(e)
                aiResult = Prefs.lastAi()
            }
            aiBusy = false
        }
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(t("tab_sensi"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        NCard {
            Text(t("sensi_warning"), fontSize = 13.sp)
            Muted(t("sensi_no_promise"))
        }

        Title(t("game"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice("FF", game == Game.FF, Modifier.weight(1f)) { pick(Game.FF) }
            Choice("FF MAX", game == Game.FFMAX, Modifier.weight(1f)) { pick(Game.FFMAX) }
            Choice("PUBG", game == Game.PUBG, Modifier.weight(1f)) { pick(Game.PUBG) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice("CODM", game == Game.CODM, Modifier.weight(1f)) { pick(Game.CODM) }
            Choice(t("g_others"), game == Game.OUTROS, Modifier.weight(1f)) { pick(Game.OUTROS) }
        }
        OutlinedTextField(value = gameVersion, onValueChange = { gameVersion = it }, label = { Text(t("game_version")) },
            modifier = Modifier.fillMaxWidth(), singleLine = true)

        Title(t("your_phone"))
        Muted(t("phone_hint"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                brand = det.brand; model = det.model; ram = String.format(Locale.US, "%.1f", det.ramGb)
                hz = det.hz.toString(); tier = det.tier; diag = det.diag; info = t("detected")
            }, modifier = Modifier.weight(1f)) { Text(t("detect"), fontSize = 12.sp) }
            OutlinedButton(onClick = { pickBrand = null; showPhones = true }, modifier = Modifier.weight(1f)) { Text(t("pick_phone"), fontSize = 12.sp) }
        }
        OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text(t("brand")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text(t("model")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = ram, onValueChange = { ram = it }, label = { Text("RAM (GB)") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = hz, onValueChange = { hz = it }, label = { Text("Hz") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Choice(t("tier1"), tier == 1, Modifier.weight(1f)) { tier = 1 }
            Choice(t("tier2"), tier == 2, Modifier.weight(1f)) { tier = 2 }
            Choice(t("tier3"), tier == 3, Modifier.weight(1f)) { tier = 3 }
        }

        Title(t("play_platform"))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            platforms.forEachIndexed { i, n -> Choice(n, platform == i, Modifier.weight(1f)) { platform = i } }
        }
        Title(t("fingers"))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            fingerNames.forEachIndexed { i, n -> Choice(n, fingers == i, Modifier.weight(1f)) { fingers = i } }
        }
        Title(t("style"))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0..2) Choice(t("st_" + STYLES[i].id), style == i, Modifier.weight(1f)) { style = i }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 3..5) Choice(t("st_" + STYLES[i].id), style == i, Modifier.weight(1f)) { style = i }
        }

        Button(onClick = { fb = 0; values = gen(0, null); info = t("suggested_local") }, modifier = Modifier.fillMaxWidth()) { Text(t("suggest_local")) }

        Title(t("infinite_title"))
        Muted(t("infinite_desc"))
        Text(t("variation") + ": ±" + jitter.roundToInt())
        Slider(value = jitter, valueRange = 2f..25f, onValueChange = { jitter = it })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { variants = variants + listOf(gen(jitter.roundToInt(), rnd)) }, modifier = Modifier.weight(1f)) { Text(t("gen_one"), fontSize = 12.sp) }
            Button(onClick = {
                val extra = (0 until 10).map { gen(jitter.roundToInt(), rnd) }
                variants = variants + extra
            }, modifier = Modifier.weight(1f)) { Text(t("gen_ten"), fontSize = 12.sp) }
            OutlinedButton(onClick = { variants = emptyList() }, modifier = Modifier.weight(1f)) { Text(t("clear"), fontSize = 12.sp) }
        }
        if (variants.isNotEmpty()) Muted(t("generated") + ": " + variants.size)
        val shown = variants.withIndex().toList().takeLast(30).reversed()
        shown.forEach { iv ->
            NCard {
                Text("#" + (iv.index + 1), fontWeight = FontWeight.Bold)
                Text(game.sliders.mapIndexed { i, s -> t("s_" + s.id) + ": " + iv.value[i] }.joinToString("  ·  "), fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { values = iv.value; info = t("applied") }) { Text(t("apply")) }
                    TextButton(onClick = { save(iv.value) }) { Text(t("save")) }
                    TextButton(onClick = { Util.copy(ctx, asText(iv.value)); info = t("copied") }) { Text(t("copy")) }
                }
            }
        }

        Title(t("controls") + " — " + game.display())
        game.sliders.forEachIndexed { i, s ->
            Text(t("s_" + s.id) + ": " + values[i] + "  (" + s.min + "–" + s.max + ")")
            Slider(
                value = values[i].toFloat(),
                onValueChange = { v -> values = values.toMutableList().also { l -> l[i] = v.roundToInt() } },
                valueRange = s.min.toFloat()..s.max.toFloat()
            )
        }

        Title(t("how_was"))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Choice(t("too_fast"), fbLabel == "fast", Modifier.weight(1f)) {
                fbLabel = "fast"; fb -= 8; values = gen(0, null); info = t("fb_down")
            }
            Choice(t("good"), fbLabel == "good", Modifier.weight(1f)) { fbLabel = "good"; info = t("fb_good") }
            Choice(t("too_slow"), fbLabel == "slow", Modifier.weight(1f)) {
                fbLabel = "slow"; fb += 8; values = gen(0, null); info = t("fb_up")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { Util.copy(ctx, asText(values)); info = t("copied") }, modifier = Modifier.weight(1f)) { Text(t("copy_values"), fontSize = 12.sp) }
            OutlinedButton(onClick = { save(values) }, modifier = Modifier.weight(1f)) { Text(t("save_config"), fontSize = 12.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pick(game) }, modifier = Modifier.weight(1f)) { Text(t("restore_default"), fontSize = 12.sp) }
            OutlinedButton(onClick = { showHow = true }, modifier = Modifier.weight(1f)) { Text(t("how_to_game"), fontSize = 12.sp) }
        }
        OutlinedButton(onClick = { showLoad = true }, modifier = Modifier.fillMaxWidth()) { Text(t("load_profile")) }
        if (info != null) Muted(info ?: "")

        NCard(border = Blue) {
            Title(t("ai_title"))
            Muted(t("ai_desc"))
            Gap(8)
            OutlinedTextField(value = difficulty, onValueChange = { difficulty = it }, label = { Text(t("ai_problem")) },
                modifier = Modifier.fillMaxWidth(), minLines = 2)
            Gap(8)
            Button(onClick = { callAi(false) }, enabled = !aiBusy, modifier = Modifier.fillMaxWidth()) { Text(t("ai_generate")) }
            OutlinedButton(onClick = { callAi(true) }, enabled = !aiBusy, modifier = Modifier.fillMaxWidth()) { Text(t("ai_search")) }
            if (aiBusy) { Gap(8); Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.padding(4.dp)); Text("  " + t("working")) } }
            if (aiMsg != null) { Gap(8); Text(aiMsg ?: "", color = Gold) }
            AnimatedVisibility(visible = aiResult != null) {
                val r = aiResult
                if (r != null) Column {
                    Gap(8)
                    if (r.savedAt != null) Muted(t("saved_at") + " " + r.savedAt)
                    if (r.values.isEmpty()) Text(t("ai_not_confirmed"), color = Gold)
                    game.sliders.forEach { s -> val v = r.values[s.id]; if (v != null) Text(t("s_" + s.id) + ": " + v) }
                    if (r.explanation.isNotBlank()) { Gap(6); Text(r.explanation, fontSize = 13.sp) }
                    if (r.values.isNotEmpty()) {
                        Gap(6)
                        OutlinedButton(onClick = {
                            values = game.sliders.mapIndexed { i, s -> r.values[s.id]?.coerceIn(s.min, s.max) ?: values[i] }
                            info = t("ai_applied")
                        }, modifier = Modifier.fillMaxWidth()) { Text(t("apply_controls")) }
                    }
                    if (r.sources.isNotEmpty()) {
                        Gap(8)
                        Text(t("sources"), fontWeight = FontWeight.Bold)
                        r.sources.forEach { sc ->
                            Text(sc.title.ifBlank { sc.url }, fontSize = 13.sp)
                            Muted(sc.url)
                            Muted(t("published") + ": " + (sc.published ?: t("no_date")) + " · " + t("consulted") + ": " + (sc.consulted ?: t("no_date")))
                        }
                    } else if (r.values.isNotEmpty()) Muted(t("ai_no_sources"))
                }
            }
        }
    }

    if (showHow) {
        AlertDialog(onDismissRequest = { showHow = false }, title = { Text(t("how_to_game")) },
            text = { Text(t(game.howKey) + "\n\n" + t("how_manual")) },
            confirmButton = { TextButton(onClick = { showHow = false }) { Text("OK") } })
    }
    if (showLoad) {
        val ps = Prefs.profiles()
        AlertDialog(onDismissRequest = { showLoad = false }, title = { Text(t("saved_profiles")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    if (ps.isEmpty()) Text(t("no_profiles"))
                    ps.forEach { p ->
                        OutlinedButton(onClick = {
                            val g = Game.values().firstOrNull { it.name == p.gameId } ?: Game.OUTROS
                            game = g
                            values = if (p.values.size == g.sliders.size) p.values else g.sliders.map { it.def }
                            info = t("loaded") + ": " + p.name
                            showLoad = false
                        }, modifier = Modifier.fillMaxWidth()) { Text(p.name + " (" + p.date + ")", fontSize = 12.sp) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showLoad = false }) { Text(t("close")) } })
    }
    if (showPhones) {
        val pb = pickBrand
        AlertDialog(onDismissRequest = { showPhones = false }, title = { Text(if (pb == null) t("brand") else pb) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    if (pb == null) {
                        PhoneDb.brands().forEach { b -> OutlinedButton(onClick = { pickBrand = b }, modifier = Modifier.fillMaxWidth()) { Text(b) } }
                    } else {
                        PhoneDb.phones.filter { it.brand == pb }.forEach { p ->
                            OutlinedButton(onClick = {
                                brand = p.brand; model = p.model; hz = p.hz.toString(); tier = p.tier; diag = p.diag
                                ram = if (p.tier == 1) "4.0" else if (p.tier == 2) "6.0" else "8.0"
                                info = t("phone_loaded") + ": " + p.model
                                showPhones = false
                            }, modifier = Modifier.fillMaxWidth()) { Text(p.model + " · " + p.hz + " Hz") }
                        }
                        TextButton(onClick = { pickBrand = null }) { Text("←") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPhones = false }) { Text(t("close")) } })
    }
    if (consentDialog) {
        AlertDialog(onDismissRequest = { consentDialog = false }, title = { Text(t("consent_title")) },
            text = { Text(t("consent_text")) },
            confirmButton = { TextButton(onClick = { Prefs.aiConsent = true; consentDialog = false; callAi(pendingSearch) }) { Text(t("allow")) } },
            dismissButton = { TextButton(onClick = { consentDialog = false }) { Text(t("not_now")) } })
    }
}
