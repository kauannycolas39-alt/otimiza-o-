package com.otimizador

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.concurrent.thread

@Composable
fun ConfigScreen(theme: Int, onTheme: (Int) -> Unit) {
    val ctx = LocalContext.current
    var sub by remember { mutableStateOf("") }
    var themeDialog by remember { mutableStateOf(false) }
    var langDialog by remember { mutableStateOf(false) }
    var consent by remember { mutableStateOf(Prefs.aiConsent) }
    var gamer by remember { mutableStateOf(Prefs.gamerAuto) }
    var autoOpt by remember { mutableStateOf(Prefs.autoOpt) }
    var notif by remember { mutableStateOf(Prefs.notif) }
    var fav by remember { mutableStateOf(Prefs.favFF) }
    var kind by remember { mutableStateOf(Prefs.aiKind) }
    var key by remember { mutableStateOf(Prefs.aiKey) }
    var model by remember { mutableStateOf(Prefs.aiModel) }
    var url by remember { mutableStateOf(Prefs.backendUrl) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var profiles by remember { mutableStateOf(Prefs.profiles()) }
    val lang = L.lang.value

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Throwable) { }
            Prefs.ffBg = uri.toString()
            AppState.bumpBg()
        }
    }

    val themeNames = listOf(t("theme_system"), t("theme_dark"), t("theme_light"))
    val langName = when (lang) { "en" -> "English"; "es" -> "Español"; else -> "Português" }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (sub.isNotEmpty()) {
            TextButton(onClick = { sub = "" }) { Text("← " + t("back")) }
        } else {
            Text(t("tab_settings"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }

        when (sub) {
            "" -> {
                SettingRow(t("theme"), themeNames[theme.coerceIn(0, 2)], { themeDialog = true })
                SettingRow(t("language"), langName, { langDialog = true })
                SettingRow(t("notifications"), t("notifications_desc"),
                    trailing = { Switch(checked = notif, onCheckedChange = { notif = it; Prefs.notif = it; if (it) Notifier.ask(ctx) }) })
                SettingRow(t("auto_opt"), t("auto_opt_desc"),
                    trailing = { Switch(checked = autoOpt, onCheckedChange = { autoOpt = it; Prefs.autoOpt = it }) })
                SettingRow(t("gamer_mode"), t("gamer_mode_desc"),
                    trailing = { Switch(checked = gamer, onCheckedChange = { gamer = it; Prefs.gamerAuto = it }) })
                SettingRow(t("ff_prefs"), t("favorite") + ": " + (if (fav == Acts.FF) "Free Fire" else if (fav == Acts.FF_MAX) "Free Fire MAX" else t("not_set")), { sub = "ff" })
                SettingRow(t("ai_settings"), if (kind == 0) t("backend") else if (kind == 1) "ChatGPT / OpenAI API" else "Claude API", { sub = "ia" })
                SettingRow(t("saved_profiles"), profiles.size.toString(), { profiles = Prefs.profiles(); sub = "perfis" })
                SettingRow(t("privacy"), t("ai_data") + ": " + (if (consent) t("allowed") else t("not_allowed")), { sub = "priv" })
                SettingRow(t("about"), null, { sub = "sobre" })
                SettingRow(t("privacy_policy"), t("sample_text"), { sub = "politica" })
                SettingRow(t("terms"), t("sample_text"), { sub = "termos" })
                OutlinedButton(onClick = { Util.xit(ctx) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("XIT", fontWeight = FontWeight.Bold) }
                Muted(t("no_hack"))
            }
            "ff" -> {
                Text(t("fav_ff"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Choice("Free Fire", fav == Acts.FF, Modifier.weight(1f)) { fav = Acts.FF; Prefs.favFF = fav }
                    Choice("FF MAX", fav == Acts.FF_MAX, Modifier.weight(1f)) { fav = Acts.FF_MAX; Prefs.favFF = fav }
                }
                Muted(t("fav_note"))
                Text(t("ff_bg"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Muted(t("ff_bg_desc"))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text(t("choose_image")) }
                    OutlinedButton(onClick = { Prefs.ffBg = ""; AppState.bumpBg() }, modifier = Modifier.weight(1f)) { Text(t("remove_image")) }
                }
            }
            "ia" -> {
                Text(t("ai_settings"), fontWeight = FontWeight.Bold)
                Muted(t("ai_provider_help"))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Choice("ChatGPT", kind == 1, Modifier.weight(1f)) { kind = 1; Prefs.aiKind = 1 }
                    Choice("Claude", kind == 2, Modifier.weight(1f)) { kind = 2; Prefs.aiKind = 2 }
                    Choice(t("backend"), kind == 0, Modifier.weight(1f)) { kind = 0; Prefs.aiKind = 0 }
                }
                if (kind == 0) {
                    Muted(t("ai_backend_help"))
                    OutlinedTextField(value = url, onValueChange = { url = it; Prefs.backendUrl = it.trim() }, label = { Text("URL (https://...)") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                } else {
                    Muted(if (kind == 1) t("ai_openai_help") else t("ai_claude_help"))
                    OutlinedTextField(value = key, onValueChange = { key = it; Prefs.aiKey = it.trim() }, label = { Text(t("api_key")) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = model, onValueChange = { model = it; Prefs.aiModel = it.trim() },
                        label = { Text(t("model_name") + " (" + AiFactory.defaultModel(kind) + ")") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Muted(t("ai_key_warning"))
                }
                SettingRow(t("allow_ai_data"), t("needed_for_ai"),
                    trailing = { Switch(checked = consent, onCheckedChange = { consent = it; Prefs.aiConsent = it }) })
                Button(onClick = {
                    val made = AiFactory.make()
                    val p = made.first
                    if (p == null) { testMsg = made.second }
                    else if (!Net.online(ctx)) { testMsg = t("offline_none") }
                    else {
                        testing = true
                        testMsg = t("working")
                        thread {
                            try {
                                if (p is DirectProvider) {
                                    p.ping()
                                    testMsg = "✔ " + t("ai_ok")
                                } else {
                                    testMsg = "✔ " + t("ai_url_ok")
                                }
                            } catch (e: Throwable) {
                                testMsg = "✘ " + AiFactory.friendly(e)
                            }
                            testing = false
                        }
                    }
                }, enabled = !testing, modifier = Modifier.fillMaxWidth()) { Text(t("test_connection")) }
                if (testMsg != null) Text(testMsg ?: "")
            }
            "perfis" -> {
                Text(t("saved_profiles"), fontWeight = FontWeight.Bold)
                if (profiles.isEmpty()) Muted(t("no_profiles"))
                profiles.forEachIndexed { idx, p ->
                    NCard {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Muted(t("saved_at") + " " + p.date)
                        val g = Game.values().firstOrNull { it.name == p.gameId }
                        Text(if (g != null && g.sliders.size == p.values.size) g.sliders.mapIndexed { i, s -> t("s_" + s.id) + ": " + p.values[i] }.joinToString("\n") else p.values.joinToString(", "), fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { Util.copy(ctx, p.name + "\n" + p.values.joinToString(", ")) }) { Text(t("copy")) }
                            OutlinedButton(onClick = {
                                val l = profiles.toMutableList()
                                l.removeAt(idx)
                                Prefs.saveProfiles(l)
                                profiles = l
                            }) { Text(t("delete")) }
                        }
                    }
                }
            }
            "priv" -> {
                Text(t("privacy"), fontWeight = FontWeight.Bold)
                Muted(t("privacy_text"))
                SettingRow(t("allow_ai_data"), null,
                    trailing = { Switch(checked = consent, onCheckedChange = { consent = it; Prefs.aiConsent = it }) })
            }
            "sobre" -> {
                val v = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" }
                Text("NitroCore", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(t("version") + ": " + v)
                Gap(8)
                Text(t("developers"), fontWeight = FontWeight.Bold)
                Text("• Nick.delaxz — " + t("dev_owner"))
                Text("• Claude (Anthropic) — " + t("dev_ai"))
                Gap(6)
                Text(t("contact"), fontWeight = FontWeight.Bold)
                Text("Instagram: @Nick.delaxz")
                OutlinedButton(onClick = { Util.openUrl(ctx, "https://instagram.com/Nick.delaxz") }, modifier = Modifier.fillMaxWidth()) { Text(t("open_instagram")) }
                Gap(8)
                Text(t("works_real"), fontWeight = FontWeight.Bold)
                Muted(t("works_real_text"))
                Text(t("needs_setup"), fontWeight = FontWeight.Bold)
                Muted(t("needs_setup_text"))
                Gap(6)
                Text(t("no_hack"), fontWeight = FontWeight.Bold)
                Muted(t("no_hack_desc"))
                Muted(t("not_affiliated"))
            }
            "politica" -> {
                Text(t("privacy_policy"), fontWeight = FontWeight.Bold)
                Muted(t("policy_text"))
            }
            "termos" -> {
                Text(t("terms"), fontWeight = FontWeight.Bold)
                Muted(t("terms_text"))
            }
        }
    }

    if (themeDialog) {
        AlertDialog(onDismissRequest = { themeDialog = false }, title = { Text(t("theme")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    themeNames.forEachIndexed { i, n -> Choice(n, theme == i, Modifier.fillMaxWidth()) { onTheme(i); themeDialog = false } }
                }
            },
            confirmButton = { TextButton(onClick = { themeDialog = false }) { Text(t("close")) } })
    }
    if (langDialog) {
        AlertDialog(onDismissRequest = { langDialog = false }, title = { Text(t("language")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Choice("Português", lang == "pt", Modifier.fillMaxWidth()) { L.set("pt"); langDialog = false }
                    Choice("English", lang == "en", Modifier.fillMaxWidth()) { L.set("en"); langDialog = false }
                    Choice("Español", lang == "es", Modifier.fillMaxWidth()) { L.set("es"); langDialog = false }
                }
            },
            confirmButton = { TextButton(onClick = { langDialog = false }) { Text(t("close")) } })
    }
}
