package com.otimizador

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private fun preset(n: Int): List<HudEl> {
    val base = listOf(
        HudEl("fire_r", 0.86f, 0.62f, 66, 90), HudEl("jump", 0.94f, 0.34f, 46, 85),
        HudEl("crouch", 0.78f, 0.88f, 42, 85), HudEl("reload", 0.66f, 0.80f, 40, 80),
        HudEl("aim", 0.72f, 0.50f, 44, 80)
    )
    val three = base + listOf(HudEl("fire_l", 0.12f, 0.58f, 58, 90), HudEl("swap", 0.30f, 0.20f, 40, 80))
    val four = three + listOf(HudEl("grenade", 0.45f, 0.20f, 38, 80), HudEl("heal", 0.55f, 0.88f, 38, 80))
    return when (n) { 2 -> base; 3 -> three; else -> four }
}

@Composable
fun HudScreen() {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    var els by remember { mutableStateOf(Prefs.hud() ?: preset(3)) }
    var sel by remember { mutableStateOf(0) }
    var info by remember { mutableStateOf<String?>(null) }

    fun asText(): String = els.joinToString("\n") { e ->
        t("h_" + e.id) + ": X " + (e.x * 100).roundToInt() + "%, Y " + (e.y * 100).roundToInt() + "%, " +
            t("size") + " " + e.size + ", " + t("opacity") + " " + e.alpha + "%"
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(t("tab_hud"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        NCard(border = Gold) {
            Text(t("hud_intro"), fontSize = 13.sp)
            Gap(4)
            Muted(t("hud_source"))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Choice(t("fingers2"), false, Modifier.weight(1f)) { els = preset(2); sel = 0 }
            Choice(t("fingers3"), false, Modifier.weight(1f)) { els = preset(3); sel = 0 }
            Choice(t("fingers4"), false, Modifier.weight(1f)) { els = preset(4); sel = 0 }
        }

        BoxWithConstraints(
            Modifier.fillMaxWidth().aspectRatio(2f).clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF101A2B)).border(1.dp, Blue, RoundedCornerShape(16.dp))
        ) {
            val wpx = with(density) { maxWidth.toPx() }
            val hpx = with(density) { maxHeight.toPx() }
            els.forEachIndexed { i, e ->
                val sz = e.size.dp
                Box(
                    Modifier
                        .offset(x = maxWidth * e.x - sz / 2, y = maxHeight * e.y - sz / 2)
                        .size(sz)
                        .alpha(e.alpha / 100f)
                        .clip(CircleShape)
                        .background(if (i == sel) Gold else Blue)
                        .pointerInput(i) {
                            detectDragGestures(onDragStart = { sel = i }) { change, drag ->
                                change.consume()
                                els = els.toMutableList().also { l ->
                                    l[i] = l[i].copy(
                                        x = (l[i].x + drag.x / wpx).coerceIn(0.02f, 0.98f),
                                        y = (l[i].y + drag.y / hpx).coerceIn(0.04f, 0.96f)
                                    )
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) { Text(t("h_" + e.id), fontSize = 9.sp, color = Color.Black, maxLines = 2) }
            }
        }
        Muted(t("hud_drag"))

        if (sel in els.indices) {
            val e = els[sel]
            NCard {
                Title(t("h_" + e.id))
                Text(t("size") + ": " + e.size)
                Slider(value = e.size.toFloat(), valueRange = 28f..110f, onValueChange = { v ->
                    els = els.toMutableList().also { l -> l[sel] = l[sel].copy(size = v.roundToInt()) }
                })
                Text(t("opacity") + ": " + e.alpha + "%")
                Slider(value = e.alpha.toFloat(), valueRange = 20f..100f, onValueChange = { v ->
                    els = els.toMutableList().also { l -> l[sel] = l[sel].copy(alpha = v.roundToInt()) }
                })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { Util.copy(ctx, asText()); info = t("copied") }, modifier = Modifier.weight(1f)) { Text(t("copy"), fontSize = 12.sp) }
            OutlinedButton(onClick = { Prefs.saveHud(els); info = t("hud_saved") }, modifier = Modifier.weight(1f)) { Text(t("save"), fontSize = 12.sp) }
            OutlinedButton(onClick = { els = preset(3); sel = 0; info = null }, modifier = Modifier.weight(1f)) { Text(t("reset"), fontSize = 12.sp) }
        }
        if (info != null) Muted(info ?: "")

        NCard {
            Title(t("hud_apply_title"))
            Gap(4)
            Text(t("hud_apply"), fontSize = 13.sp)
            Gap(6)
            Muted(t("hud_tip"))
        }
    }
}
