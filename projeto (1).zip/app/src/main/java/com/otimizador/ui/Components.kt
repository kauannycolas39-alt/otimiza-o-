package com.otimizador

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Blue = Color(0xFF00A3FF)
val Green = Color(0xFF39FF14)
val Gold = Color(0xFFFFB300)
val FireRed = Color(0xFFFF3D00)
val FireOrange = Color(0xFFFF8F00)

@Composable
fun isDark(mode: Int): Boolean = when (mode) { 1 -> true; 2 -> false; else -> isSystemInDarkTheme() }

@Composable
fun NitroTheme(mode: Int, content: @Composable () -> Unit) {
    val scheme = if (isDark(mode)) darkColorScheme(
        primary = Blue, onPrimary = Color.Black, secondary = Green,
        background = Color(0xFF05080F), surface = Color(0xFF0E1A2B),
        onBackground = Color.White, onSurface = Color.White,
        surfaceVariant = Color(0xFF16202F), onSurfaceVariant = Color(0xFFB8C4D6)
    ) else lightColorScheme(primary = Color(0xFF0077CC), secondary = Color(0xFF1B8A00))
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun NCard(modifier: Modifier = Modifier, border: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (border != null) BorderStroke(1.5.dp, border) else null
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun Title(txt: String) = Text(txt, fontSize = 18.sp, fontWeight = FontWeight.Bold)

@Composable
fun Muted(txt: String, modifier: Modifier = Modifier) =
    Text(txt, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = modifier)

@Composable
fun Gap(h: Int = 12) = Spacer(Modifier.height(h.dp))

@Composable
fun Choice(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick, modifier = modifier) { Text(label, fontSize = 13.sp, maxLines = 1) }
    else OutlinedButton(onClick = onClick, modifier = modifier) { Text(label, fontSize = 13.sp, maxLines = 1) }
}

@Composable
fun Meter(label: String, value: String, progress: Float?, color: Color = Blue) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp)
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        if (progress != null) {
            LinearProgressIndicator(progress = progress.coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth().height(6.dp), color = color)
        }
    }
}

@Composable
fun StatusCard(s: DeviceStatus) {
    NCard(border = Blue) {
        Title(t("device_mgmt"))
        Gap(6)
        Meter(t("ram"), s.ramUsedMb.toString() + " / " + s.ramTotalMb + " MB", s.ramUsedMb.toFloat() / s.ramTotalMb.coerceAtLeast(1L).toFloat(),
            if (s.ramUsedMb * 100 / s.ramTotalMb.coerceAtLeast(1L) > 85) FireRed else Blue)
        Meter(t("storage"), String.format(java.util.Locale.US, "%.1f / %.0f GB", s.storageUsedGb, s.storageTotalGb),
            (s.storageUsedGb / s.storageTotalGb.coerceAtLeast(1.0)).toFloat())
        val bat = s.batteryPct
        Meter(t("battery"), if (bat == null) t("unavailable") else bat.toString() + "%" + (if (s.charging == true) " ⚡" else ""),
            if (bat == null) null else bat / 100f, Green)
        val tc = s.tempC
        Meter(t("temp"), if (tc == null) t("unavailable") else String.format(java.util.Locale.US, "%.1f °C", tc),
            if (tc == null) null else (tc / 60f), if (tc != null && tc > 42f) FireRed else Gold)
        val v = s.voltageV
        if (v != null) Meter(t("voltage"), String.format(java.util.Locale.US, "%.2f V", v), null)
    }
}

@Composable
fun ActionRow(icon: ImageVector, title: String, desc: String, button: String, enabled: Boolean = true, onClick: () -> Unit) {
    NCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Blue, modifier = Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Muted(desc)
            }
            Button(onClick = onClick, enabled = enabled) { Text(button) }
        }
    }
}

@Composable
fun SettingRow(title: String, subtitle: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {
    Icon(Icons.Default.KeyboardArrowRight, contentDescription = null)
}) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = onClick != null) { onClick?.invoke() }.padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, fontSize = 16.sp)
            if (subtitle != null) Muted(subtitle)
        }
        trailing()
    }
}

/** Botão do Free Fire com tema de fogo (arte própria). Pode usar uma imagem escolhida pelo usuário como fundo. */
@Composable
fun FireButton(text: String, sub: String, bg: ImageBitmap?, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF8E0000), FireRed, FireOrange, Color(0xFFFFB300))))
            .clickable { onClick() }
    ) {
        if (bg != null) {
            Image(bitmap = bg, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
        } else {
            Canvas(Modifier.matchParentSize()) {
                val w = size.width
                val h = size.height
                val n = 7
                for (i in 0 until n) {
                    val cx = w * (i + 0.5f) / n
                    val fh = h * (0.45f + 0.25f * ((i * 37) % 5) / 4f)
                    val p = Path()
                    p.moveTo(cx - w / (n * 1.6f), h)
                    p.quadraticBezierTo(cx - w / (n * 3f), h - fh * 0.5f, cx, h - fh)
                    p.quadraticBezierTo(cx + w / (n * 3f), h - fh * 0.5f, cx + w / (n * 1.6f), h)
                    p.close()
                    drawPath(p, Color(0x55FFE082))
                }
            }
        }
        Box(Modifier.matchParentSize().background(Color(if (bg != null) 0x66000000 else 0x22000000)))
        Column(Modifier.align(Alignment.CenterStart).padding(20.dp)) {
            Text(text, fontSize = 26.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text(sub, fontSize = 13.sp, color = Color.White)
        }
        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 20.dp).size(56.dp))
    }
}
