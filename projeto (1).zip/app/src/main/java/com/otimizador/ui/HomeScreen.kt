package com.otimizador

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.concurrent.thread

@Composable
fun shizukuText(): String {
    val st = Shell.status()
    return t("shizuku") + ": " + (if (st == "ok") t("sz_ok") else if (st == "perm") t("sz_perm") else t("sz_off"))
}

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val tick = AppState.tick.value
    var status by remember { mutableStateOf(Device.status(ctx)) }
    val details = remember { Device.details(ctx) }
    var busy by remember { mutableStateOf(false) }
    var autoRes by remember { mutableStateOf<List<ActionResult>>(emptyList()) }
    var ffDialog by remember { mutableStateOf(false) }
    var tip by remember { mutableStateOf((0..5).random()) }
    val bgTick = AppState.bgTick.value
    val bg = remember(bgTick) { if (Prefs.ffBg.isBlank()) null else Util.loadBg(ctx, Prefs.ffBg) }
    val shz = Shell.status()

    LaunchedEffect(tick) {
        while (true) {
            status = Device.status(ctx)
            delay(3000)
        }
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_launcher), contentDescription = null, modifier = Modifier.size(56.dp))
            Column(Modifier.padding(start = 12.dp)) {
                Text("NitroCore", fontSize = 26.sp, fontWeight = FontWeight.Black)
                Muted(t("tagline"))
            }
        }

        FireButton(t("play_ff"), t("play_ff_sub"), bg) { ffDialog = true }

        Button(
            onClick = {
                if (!busy) {
                    busy = true
                    Auto.run(ctx, true) { r -> autoRes = r; busy = false }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
        ) { Text(t("auto_play"), fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        Muted(t("auto_play_desc"))

        if (busy) {
            NCard { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(26.dp)); Text("  " + t("working")) } }
        }
        if (autoRes.isNotEmpty() && !busy) {
            NCard(border = Green) {
                Title(t("result"))
                autoRes.forEach { r ->
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.Top) {
                        Icon(if (r.ok) Icons.Default.CheckCircle else Icons.Default.Warning, contentDescription = null,
                            tint = if (r.ok) Green else Gold, modifier = Modifier.size(20.dp))
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(r.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Muted(r.message.take(120))
                        }
                    }
                }
            }
        }

        NCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(shizukuText(), fontWeight = FontWeight.Bold)
                if (shz == "perm") TextButton(onClick = { Shell.requestPermission() }) { Text(t("grant")) }
            }
            if (shz == "off") Muted(t("sz_help"))
        }

        StatusCard(status)

        NCard {
            Title(t("your_device"))
            Gap(6)
            Meter(t("model"), details.brand + " " + details.model, null)
            Meter("Android", details.android, null)
            Meter(t("cpu"), details.cores.toString() + " " + t("cores") + " · " + details.abi, null)
            Meter(t("screen"), details.resolution + " · " + details.dpi + " dpi · " + details.hz + " Hz", null)
            Meter(t("uptime"), details.uptime, null)
        }

        NCard(border = Gold) {
            Title(t("tip_title"))
            Gap(4)
            Text(t("tip" + tip), fontSize = 14.sp)
            TextButton(onClick = { tip = (tip + 1) % 6 }) { Text(t("next_tip")) }
        }

        NCard {
            Text(t("no_hack"), fontWeight = FontWeight.Bold, color = FireRed)
            Muted(t("no_hack_desc"))
            Gap(8)
            OutlinedButton(onClick = { Util.xit(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("XIT", fontWeight = FontWeight.Bold) }
        }
    }

    if (ffDialog) FfDialog { ffDialog = false }
}

@Composable
fun FfDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(if (Prefs.favFF.isNotBlank()) Prefs.favFF else Acts.FF) }
    var fav by remember { mutableStateOf(Prefs.favFF) }
    var msg by remember { mutableStateOf<String?>(null) }
    val pkgs = listOf(Acts.FF to "Free Fire", Acts.FF_MAX to "Free Fire MAX")

    fun go(optimize: Boolean) {
        if (!Games.installed(ctx, sel)) { msg = t("ff_not_installed"); return }
        if (optimize) {
            onDismiss()
            val target = sel
            thread {
                val r = Optimizer.run(ctx, "kill")
                val g = Optimizer.run(ctx, if (target == Acts.FF_MAX) "gmf_max" else "gmf_ff")
                if (r.ok || g.ok) Notifier.optimized(ctx)
                android.os.Handler(android.os.Looper.getMainLooper()).post { Games.launch(ctx, target) }
            }
        } else {
            onDismiss()
            Games.launch(ctx, sel)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(t("play_ff")) },
        confirmButton = {},
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                pkgs.forEach { (pkg, name) ->
                    val inst = Games.installed(ctx, pkg)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Choice(name + " · " + (if (inst) t("installed") else t("not_installed")), sel == pkg, Modifier.weight(1f)) { sel = pkg; msg = null }
                        TextButton(onClick = { Prefs.favFF = pkg; fav = pkg }) { Text(if (fav == pkg) "★" else "☆", fontSize = 20.sp) }
                    }
                }
                if (msg != null) {
                    Text(msg ?: "", color = Gold)
                    OutlinedButton(onClick = { Games.openStore(ctx, sel) }, modifier = Modifier.fillMaxWidth()) { Text(t("open_store")) }
                }
                Button(onClick = { go(Prefs.gamerAuto) }, modifier = Modifier.fillMaxWidth()) { Text(t("open_now")) }
                OutlinedButton(onClick = { go(true) }, modifier = Modifier.fillMaxWidth()) { Text(t("opt_before")) }
                TextButton(onClick = onDismiss) { Text(t("cancel")) }
                Muted(t("fav_note"))
            }
        }
    )
}
