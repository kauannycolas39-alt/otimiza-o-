package com.otimizador

data class SliderDef(val id: String, val min: Int, val max: Int, val basePct: Int, val def: Int, val group: Int)

private fun s(id: String, mn: Int, mx: Int, b: Int, d: Int, g: Int) = SliderDef(id, mn, mx, b, d, g)

private fun ffSliders() = listOf(
    s("general", 0, 200, 60, 100, 0), s("reddot", 0, 200, 55, 100, 0),
    s("scope2x", 0, 200, 50, 100, 1), s("scope4x", 0, 200, 45, 100, 1),
    s("awm", 0, 200, 38, 100, 2), s("freelook", 0, 200, 45, 100, 0)
)

enum class Game(val label: String, val pkg: String?, val sliders: List<SliderDef>, val howKey: String) {
    FF("Free Fire", "com.dts.freefireth", ffSliders(), "how_ff"),
    FFMAX("Free Fire MAX", "com.dts.freefiremax", ffSliders(), "how_ff"),
    PUBG("PUBG Mobile", "com.tencent.ig", listOf(
        s("pubg_cam", 1, 300, 38, 100, 0), s("pubg_red", 1, 300, 30, 50, 0),
        s("pubg_2x", 1, 300, 26, 40, 1), s("pubg_4x", 1, 300, 22, 30, 1)), "how_pubg"),
    CODM("Call of Duty Mobile", "com.activision.callofduty.shooter", listOf(
        s("codm_cam", 0, 200, 50, 100, 0), s("codm_ads", 0, 200, 50, 100, 1),
        s("codm_red", 0, 200, 48, 100, 1), s("codm_sniper", 0, 200, 40, 80, 2)), "how_codm"),
    OUTROS("", null, listOf(
        s("gen_general", 0, 100, 60, 50, 0), s("gen_aim", 0, 100, 55, 50, 1), s("gen_free", 0, 100, 55, 50, 0)), "how_other");

    fun display(): String = if (this == OUTROS) t("g_others") else label
}

data class StyleDef(val id: String, val gen: Int, val scope: Int, val awm: Int)

val STYLES = listOf(
    StyleDef("precise", -10, -10, -8), StyleDef("balanced", 0, 0, 0), StyleDef("fast", 10, 8, 5),
    StyleDef("rush", 15, 5, 0), StyleDef("sniper", -5, -12, 10), StyleDef("defensive", -8, -4, -4)
)

data class Phone(val brand: String, val model: String, val diag: Double, val hz: Int, val tier: Int)

object PhoneDb {
    val phones = listOf(
        Phone("Motorola", "Moto G04", 6.56, 90, 1), Phone("Motorola", "Moto G24", 6.56, 90, 1),
        Phone("Motorola", "Moto G34 5G", 6.5, 120, 2), Phone("Motorola", "Moto G54 5G", 6.5, 120, 2),
        Phone("Motorola", "Moto G84 5G", 6.5, 120, 2), Phone("Motorola", "Moto G85", 6.67, 120, 2),
        Phone("Motorola", "Edge 40 Neo", 6.55, 144, 2), Phone("Motorola", "Edge 50 Fusion", 6.7, 120, 2),
        Phone("Samsung", "Galaxy A04", 6.5, 60, 1), Phone("Samsung", "Galaxy A14", 6.6, 90, 1),
        Phone("Samsung", "Galaxy A15", 6.5, 90, 1), Phone("Samsung", "Galaxy A25 5G", 6.5, 120, 2),
        Phone("Samsung", "Galaxy A35 5G", 6.6, 120, 2), Phone("Samsung", "Galaxy A54 5G", 6.4, 120, 2),
        Phone("Samsung", "Galaxy A55 5G", 6.6, 120, 2), Phone("Samsung", "Galaxy M14", 6.6, 90, 1),
        Phone("Samsung", "Galaxy S23", 6.1, 120, 3), Phone("Samsung", "Galaxy S24", 6.2, 120, 3),
        Phone("Samsung", "Galaxy S24 Ultra", 6.8, 120, 3),
        Phone("Xiaomi / Redmi / Poco", "Redmi 12C", 6.71, 60, 1), Phone("Xiaomi / Redmi / Poco", "Redmi 12", 6.79, 90, 1),
        Phone("Xiaomi / Redmi / Poco", "Redmi Note 12", 6.67, 120, 2), Phone("Xiaomi / Redmi / Poco", "Redmi Note 13", 6.67, 120, 2),
        Phone("Xiaomi / Redmi / Poco", "Redmi Note 13 Pro", 6.67, 120, 2), Phone("Xiaomi / Redmi / Poco", "Poco C65", 6.74, 90, 1),
        Phone("Xiaomi / Redmi / Poco", "Poco M6", 6.79, 90, 1), Phone("Xiaomi / Redmi / Poco", "Poco X5 Pro", 6.67, 120, 2),
        Phone("Xiaomi / Redmi / Poco", "Poco X6 Pro", 6.67, 120, 3), Phone("Xiaomi / Redmi / Poco", "Poco F5", 6.67, 120, 3),
        Phone("Infinix", "Hot 40i", 6.56, 90, 1), Phone("Infinix", "Hot 40 Pro", 6.78, 120, 1), Phone("Infinix", "Note 40", 6.78, 120, 2),
        Phone("Realme", "C55", 6.72, 90, 1), Phone("Realme", "C67", 6.72, 90, 1), Phone("Realme", "12 Pro", 6.7, 120, 2),
        Phone("Gamer", "ASUS ROG Phone 8", 6.78, 165, 3), Phone("Gamer", "Red Magic 9 Pro", 6.8, 120, 3)
    )
    fun brands(): List<String> = phones.map { it.brand }.distinct()
}

data class DeviceProfile(val brand: String, val model: String, val ramGb: Double, val hz: Int, val tier: Int, val diag: Double)

data class DeviceStatus(
    val ramUsedMb: Long, val ramTotalMb: Long,
    val storageUsedGb: Double, val storageTotalGb: Double,
    val tempC: Float?, val batteryPct: Int?, val charging: Boolean?, val voltageV: Float?
)

data class DeviceDetails(
    val brand: String, val model: String, val android: String, val abi: String,
    val cores: Int, val hz: Int, val resolution: String, val dpi: Int, val uptime: String
)

data class ActionResult(val title: String, val ok: Boolean, val message: String, val settingsAction: String? = null)

data class Profile(val name: String, val gameId: String, val values: List<Int>, val date: String)

data class Source(val title: String, val url: String, val published: String?, val consulted: String?)

data class AiResult(
    val values: Map<String, Int>, val explanation: String,
    val sources: List<Source>, val verified: Boolean, val savedAt: String? = null
) {
    companion object {
        fun parse(j: org.json.JSONObject, savedAt: String? = null): AiResult {
            val vals = mutableMapOf<String, Int>()
            j.optJSONObject("values")?.let { o -> o.keys().forEach { k -> vals[k] = o.optInt(k) } }
            val srcs = mutableListOf<Source>()
            j.optJSONArray("sources")?.let { a ->
                for (i in 0 until a.length()) {
                    val x = a.getJSONObject(i)
                    srcs.add(Source(x.optString("title"), x.optString("url"),
                        x.optString("publishedAt").ifBlank { null }, x.optString("consultedAt").ifBlank { null }))
                }
            }
            return AiResult(vals, j.optString("explanation"), srcs, j.optBoolean("verified", false), savedAt)
        }
    }
}

data class HudEl(val id: String, val x: Float, val y: Float, val size: Int, val alpha: Int)

data class Act(val id: String, val script: String? = null, val settings: String? = null)
