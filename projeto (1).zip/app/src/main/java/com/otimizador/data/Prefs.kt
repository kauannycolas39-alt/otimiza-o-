package com.otimizador

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) { sp = ctx.getSharedPreferences("nitrocore", Context.MODE_PRIVATE) }

    fun now(): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

    private fun str(k: String, d: String = ""): String = sp.getString(k, d) ?: d

    var lang: String
        get() = str("lang", when (Locale.getDefault().language) { "en" -> "en"; "es" -> "es"; else -> "pt" })
        set(v) { sp.edit().putString("lang", v).apply() }

    var theme: Int
        get() = sp.getInt("theme", 1)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var favFF: String
        get() = str("fav_ff")
        set(v) { sp.edit().putString("fav_ff", v).apply() }

    var gamerAuto: Boolean
        get() = sp.getBoolean("gamer_auto", false)
        set(v) { sp.edit().putBoolean("gamer_auto", v).apply() }

    var autoOpt: Boolean
        get() = sp.getBoolean("auto_opt", false)
        set(v) { sp.edit().putBoolean("auto_opt", v).apply() }

    var notif: Boolean
        get() = sp.getBoolean("notif", false)
        set(v) { sp.edit().putBoolean("notif", v).apply() }

    var aiConsent: Boolean
        get() = sp.getBoolean("ai_consent", false)
        set(v) { sp.edit().putBoolean("ai_consent", v).apply() }

    var aiKind: Int
        get() = sp.getInt("ai_kind", 1)
        set(v) { sp.edit().putInt("ai_kind", v).apply() }

    var aiKey: String
        get() = str("ai_key")
        set(v) { sp.edit().putString("ai_key", v).apply() }

    var aiModel: String
        get() = str("ai_model")
        set(v) { sp.edit().putString("ai_model", v).apply() }

    var backendUrl: String
        get() = str("backend_url")
        set(v) { sp.edit().putString("backend_url", v).apply() }

    var ffBg: String
        get() = str("ff_bg")
        set(v) { sp.edit().putString("ff_bg", v).apply() }

    var hudJson: String
        get() = str("hud")
        set(v) { sp.edit().putString("hud", v).apply() }

    fun saveLastAi(json: String) {
        sp.edit().putString("last_ai", json).putString("last_ai_date", now()).apply()
    }

    fun lastAi(): AiResult? {
        val raw = sp.getString("last_ai", null) ?: return null
        return try { AiResult.parse(JSONObject(raw), sp.getString("last_ai_date", null)) } catch (e: Exception) { null }
    }

    fun profiles(): List<Profile> = try {
        val a = JSONArray(str("profiles", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val v = o.getJSONArray("values")
            Profile(o.getString("name"), o.getString("game"), (0 until v.length()).map { k -> v.getInt(k) }, o.getString("date"))
        }
    } catch (e: Exception) { emptyList() }

    fun saveProfiles(list: List<Profile>) {
        val a = JSONArray()
        list.forEach { p ->
            a.put(JSONObject().put("name", p.name).put("game", p.gameId).put("values", JSONArray(p.values)).put("date", p.date))
        }
        sp.edit().putString("profiles", a.toString()).apply()
    }

    fun hud(): List<HudEl>? = try {
        val a = JSONArray(hudJson)
        if (a.length() == 0) null else (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            HudEl(o.getString("id"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getInt("size"), o.getInt("alpha"))
        }
    } catch (e: Exception) { null }

    fun saveHud(list: List<HudEl>) {
        val a = JSONArray()
        list.forEach { e -> a.put(JSONObject().put("id", e.id).put("x", e.x.toDouble()).put("y", e.y.toDouble()).put("size", e.size).put("alpha", e.alpha)) }
        hudJson = a.toString()
    }
}
