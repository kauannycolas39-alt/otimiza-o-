package com.otimizador

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

object AppState {
    val tick = mutableStateOf(0)
    val bgTick = mutableStateOf(0)
    fun bump() { tick.value = tick.value + 1 }
    fun bumpBg() { bgTick.value = bgTick.value + 1 }
}

class MainActivity : ComponentActivity() {
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> AppState.bump() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        L.init()
        Shizuku.addRequestPermissionResultListener(permListener)
        setContent { App() }
        if (savedInstanceState == null && Prefs.autoOpt && Shell.available()) {
            Auto.run(this, true) { }
        }
    }

    override fun onResume() {
        super.onResume()
        AppState.bump()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }
}

@Composable
fun App() {
    var theme by remember { mutableStateOf(Prefs.theme) }
    NitroTheme(theme) {
        var tab by remember { mutableStateOf(0) }
        val bgBrush = if (isDark(theme)) Brush.verticalGradient(listOf(Color(0xFF0B2347), Color(0xFF06101F), Color(0xFF05080F)))
        else Brush.verticalGradient(listOf(Color(0xFFEAF3FF), Color(0xFFFFFFFF)))
        Scaffold(
            containerColor = Color.Transparent,
            modifier = Modifier.background(bgBrush),
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = null) }, label = { Text(t("tab_home"), fontSize = 10.sp, maxLines = 1) })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Build, contentDescription = null) }, label = { Text(t("tab_opt"), fontSize = 10.sp, maxLines = 1) })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Edit, contentDescription = null) }, label = { Text(t("tab_sensi"), fontSize = 10.sp, maxLines = 1) })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.PlayArrow, contentDescription = null) }, label = { Text("HUD", fontSize = 10.sp, maxLines = 1) })
                    NavigationBarItem(selected = tab == 4, onClick = { tab = 4 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) }, label = { Text(t("tab_settings"), fontSize = 10.sp, maxLines = 1) })
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen()
                    1 -> OptimizeScreen()
                    2 -> SensiScreen()
                    3 -> HudScreen()
                    else -> ConfigScreen(theme) { theme = it; Prefs.theme = it }
                }
            }
        }
    }
}
