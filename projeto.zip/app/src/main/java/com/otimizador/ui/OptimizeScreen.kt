package com.otimizador

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.concurrent.thread

private fun iconFor(id: String): ImageVector = when (id) {
    "fluid" -> Icons.Default.Refresh
    "gm_max", "gm_ff" -> Icons.Default.PlayArrow
    "cache" -> Icons.Default.Delete
    "kill" -> Icons.Default.Refresh
    "battery" -> Icons.Default.Favorite
    "restore" -> Icons.Default.Settings
    else -> Icons.Default.Build
}

@Composable
fun OptimizeScreen() {
    val ctx = LocalContext.current
    val tick = AppState.tick.value
    var status by remember { mutableStateOf(Device.status(ctx)) }
    var running by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<ActionResult>>(emptyList()) }
    var confirmFiles by remember { mutableStateOf(false) }

    LaunchedEffect(tick) {
        while (true) {
            status = Device.status(ctx)
            delay(3000)
        }
    }

    fun runIds(name: String, ids: List<String>) {
        if (running != null) return
        running = name
        thread {
            val r = ids.map { Optimizer.run(ctx, it) }
            if (ids.size > 1 && r.any { it.ok }) Notifier.optimized(ctx)
            results = r
            status = Device.status(ctx)
            running = null
        }
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(t("tab_opt"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Muted(shizukuText())
        if (Shell.status() == "perm") {
            Button(onClick = { Shell.requestPermission() }, modifier = Modifier.fillMaxWidth()) { Text(t("grant")) }
        }

        StatusCard(status)

        Button(
            onClick = { runIds(t("auto_btn"), Auto.ids(ctx)) },
            enabled = running == null,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
        ) { Text(t("auto_btn"), fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Muted(t("auto_desc"))

        if (running != null) {
            NCard { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(28.dp)); Text("  " + running + "...") } }
        }

        AnimatedVisibility(visible = results.isNotEmpty()) {
            NCard(border = Blue) {
                Title(t("result"))
                Muted(t("result_note"))
                results.forEach { r ->
                    Gap(10)
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(if (r.ok) Icons.Default.CheckCircle else Icons.Default.Warning, contentDescription = null,
                            tint = if (r.ok) Green else Gold, modifier = Modifier.size(22.dp))
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(r.title, fontWeight = FontWeight.Bold)
                            Text(r.message, fontSize = 13.sp)
                            if (r.settingsAction != null) {
                                TextButton(onClick = { Games.openSettings(ctx, r.settingsAction) }) { Text(t("open_settings")) }
                            }
                        }
                    }
                }
            }
        }

        Title(t("all_options"))
        Acts.visible.forEach { id ->
            ActionRow(iconFor(id), t("a_" + id), t("d_" + id), t("run"), running == null) {
                runIds(t("a_" + id), listOf(id))
            }
        }
        ActionRow(Icons.Default.Search, t("a_own_cache"), t("d_own_cache"), t("clean"), running == null) { confirmFiles = true }
        ActionRow(Icons.Default.Share, t("a_brevent"), t("d_brevent"), t("copy"), true) {
            Util.copy(ctx, Acts.brevent())
            results = listOf(ActionResult(t("a_brevent"), true, t("copied")))
        }
    }

    if (confirmFiles) {
        AlertDialog(
            onDismissRequest = { confirmFiles = false },
            title = { Text(t("confirm_clean_title")) },
            text = { Text(t("confirm_clean_text")) },
            confirmButton = {
                TextButton(onClick = {
                    confirmFiles = false
                    results = listOf(Optimizer.cleanOwnCache(ctx))
                }) { Text(t("clean")) }
            },
            dismissButton = { TextButton(onClick = { confirmFiles = false }) { Text(t("cancel")) } }
        )
    }
}
